<html>
<head>
<title>PHP Emailer Test Page</title>
</head>
<body>
<?php
    if (!empty($_POST))
    {
        echo "There is Post Data <br>";
        
        $postParmCount = 1;
        $postParmList = "";
        
        foreach ($_POST as $postParmValue)
        {
            echo "Post Parameter $postParmCount is " . htmlentities($postParmValue) . "<br>";
            $postParmList = $postParmList . $postParmValue . " ";
            $postParmCount++;
        }

        $name = "";
        $email = "";
        $date = "";
        $location = "";

        if (!empty($_POST["name"])) {
            $name = htmlentities($_POST["name"]);
            echo "Yes, name is set<br>";    
        }
        
        else{
            echo "No, name is not set<br>";
        }

        if (!empty($_POST["email"])) {
            $email = htmlentities($_POST["email"]);
            echo "Yes, email is set <br>";    
        }
        
        else{
            echo "No, email is not set<br>";
        }

        
        if (!empty($_POST["date"])) {
            $date = htmlentities($_POST["date"]);
            echo "Yes, date is set <br>";    
        }
        
        else{
            echo "No, date is not set<br>";
        }

        if (!empty($_POST["location"])) {
            $location = htmlentities($_POST["location"]);
            echo "Yes, location is set <br>";    
        }
        
        else{
            echo "No, location is not set<br>";
        }

        echo "Attempting to Send Email...";

        $serverDateTime = date("l, M jS Y",time()) . " at " . date("g:ia T", time());
        
        $to = "dwercr@gmail.com";
        $subject = "New Appointment request from " . $_SERVER['HTTP_HOST'];
        $body = "<html><body><table>";
        $body .= "<b>You have a new Appointment request!</b>";
        $body .= "<br><br><tr><td>Name</td><td>$name</td></tr>"; 
        $body .= "<tr><td>Email</td><td>$email</td></tr>";
        $body .= "<tr><td>Date</td><td>$date</td></tr>"; 
        $body .= "<tr><td>Location</td><td>$location</td></tr>";
        $body .= "<br><br>Click <b><a href = 'http://playground.hotaru-development.com/json.html'>here</a></b> to navigate to your Appointment Portal and manage this request";
        $body .= "<br><i>This email was sent on $serverDateTime</i>";
        $body .= "</table></body></html>";
       
        $headers = 'From: webmaster@hotaru-development.com' . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        
        if(mail($to, $subject, $body, $headers))
        {
            //mail was sent
            echo "Sucessful!  Mail was sent!";
            //echo "<script>window.location='http://playground.hotaru-development.com/testform.html'</script>";         
        }
        
        else
        {
            //mail was not sent
            echo "Fail! Mail was not sent!";
        }
    }
    
    else
    {
        //$_POST is empty
        echo "No Post Data";
    }
?>
</body>
</html>