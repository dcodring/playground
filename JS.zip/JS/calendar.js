﻿var authFailures = 0;

var gCalApiKey = "AIzaSyApTR3m69wv5EahsUhLquMwjDGkQ9CTAdU";
var gCalClientId = "429709235512-ebruk3ru2am4sve8gv93p7okqp8nqf5c.apps.googleusercontent.com";
var gCalId = "primary";
var gCalScope = 'https://www.googleapis.com/auth/calendar';
var xhr;

function eventsShowLoading()
{
    //show loading events
    var loadingEventDiv = document.createElement("div");
    loadingEventDiv.id = "eventsLoadingDivId";
    loadingEventDiv.className = "regularText";
    loadingEventDiv.innerHTML = "Loading Events...";
    document.getElementById("eventsDivId").appendChild(loadingEventDiv);
}

function gCalAddEvent(calendarId, startTime, endTime, location, summary)
{
    xhr = new XMLHttpRequest();
    var oauthToken = gapi.auth.getToken();
    var params = "{ 'end':{'dateTime':'" + endTime + "'}, 'location':'" + location + "', 'start':{'dateTime':'" + startTime + "'}, 'summary':'" + summary + "'}";

    xhr.open('POST', 'https://www.googleapis.com/calendar/v3/calendars/' + calendarId + '/events?key=' + gCalApiKey, true);
    xhr.setRequestHeader('Authorization', 'Bearer ' + oauthToken.access_token);
    xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            //response is finished so refresh events
            document.getElementById("responseId").value = xhr.responseText;
            eventsShowLoading();
            gCalGetEventsForToday(gCalId);
        }
    }

    xhr.send(params);
}

function gCalAuthorise()
{
    //show loading events while this is going on
    eventsShowLoading();

    //start the authorization process
    gapi.client.setApiKey(gCalApiKey);
    gapi.auth.authorize({client_id:gCalClientId, scope:gCalScope, immediate:true}, gCalHandleAuthResult);
}
 
function gCalGetEventsForToday(calendarId)
{
    todayDate = getTodayDate().toISOString();

    //the end date is always the next day at midnight
    endDate = getTodayDate();
    endDate.setDate(endDate.getDate() + 1);
    endDate.setHours(0, 0, 0, 0);
    endDate = endDate.toISOString();

    document.getElementById("todayDateResultId").innerHTML = todayDate;
    document.getElementById("endDateResultId").innerHTML = endDate;

    xhr = new XMLHttpRequest();
    var oauthToken = gapi.auth.getToken();

    //get the single events from the selected calendar
    xhr.open('GET', 'https://www.googleapis.com/calendar/v3/calendars/' + calendarId + '/events?singleEvents=true&timeMin=' + todayDate + '&timeMax=' + endDate + '&orderBy=startTime');
    xhr.setRequestHeader('Authorization', 'Bearer ' + oauthToken.access_token);

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            //response is finished
            document.getElementById("responseId").value = xhr.responseText;
            gCalShowEvents(xhr.responseText);
        }
    }

    xhr.send();
}

function gCalGetCalendarInfo(calendarId)
{    
    xhr = new XMLHttpRequest();
    var oauthToken = gapi.auth.getToken();

    //get the calendar with specified calendarId
    xhr.open('GET', 'https://www.googleapis.com/calendar/v3/calendars/' + calendarId);
    xhr.setRequestHeader('Authorization', 'Bearer ' + oauthToken.access_token);

    xhr.onreadystatechange=function() {
        if (xhr.readyState==4) {
            document.getElementById("responseId").value = xhr.responseText;
        }
    }
             
    xhr.send();
}

function gCalHandleAuthResult(authResult) {
    myResult = authResult;

    if ((authResult) && (!authResult.error)) {
        //auth was successful

        document.getElementById("authResultId").innerHTML = "success";
        gCalGetEventsForToday(gCalId);
        //gCalAddEvent(gCalId, "2014-05-18T23:30:00-07:00", "2014-05-19T01:00:00-07:00", "test location", "test summary");
    }
    else {
        //auth was not successful
        document.getElementById("authResultId").innerHTML = "failure";

        if (authFailures < 1) {
            //maybe the token just isn't set lets have the user help us out but try this only once
            gapi.auth.authorize({ client_id: gCalClientId, scope: gCalScope, immediate: false }, gCalHandleAuthResult);
        }

        else {
            //failed the 2nd time as well
            document.getElementById("eventsLoadingDivId").innerHTML = "Loading Events...Failed!";
        }

        authFailures++;
    }
}
        
function gCalShowEvents(xhrIn)
{
    var eventJson = JSON.parse(xhrIn);
    eventItems = eventJson.items;
    document.getElementById("eventsDivId").removeChild(document.getElementById("eventsLoadingDivId"));
    document.getElementById("eventsDivId").innerHTML = "";
    
    if (eventItems.length > 0)
    {
        //if there are any events
        for (thisEvent = 0; thisEvent < eventItems.length; thisEvent++)
        {
            var thisEventDiv = document.createElement("div");
            thisEventDiv.className = "calendarItem";
            var startTime = new Date(eventItems[thisEvent].start.dateTime).toLocaleTimeString("en-us", {hour:"2-digit", minute:"2-digit"});
            var endTime = new Date(eventItems[thisEvent].end.dateTime).toLocaleTimeString("en-us", {hour:"2-digit", minute:"2-digit" });
            thisEventDiv.innerHTML = "<b><a href='" + eventItems[thisEvent].htmlLink + "' class='calendarEventTitle' target='_blank' title='Edit Appointment directly in Google Calendar'>" + eventItems[thisEvent].summary + "</a></b><br>" + startTime + " to " + endTime + "<br><i class ='regularText'>" + eventItems[thisEvent].location + "</i>";
            document.getElementById("eventsDivId").appendChild(thisEventDiv);
        }
    }

    else
    {
        //no events today
        document.getElementById("eventsDivId").innerHTML = "<i class='regularText'>No Appointments Scheduled for today</i>";
    }
}

function getTodayDate() {
    var todayDate = new Date();
    return todayDate;
}