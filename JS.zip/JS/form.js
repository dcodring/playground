﻿var submitButtonElement;

function submitForm()
{
    submitButtonElement = document.getElementById("submitButtonId");

    submitButtonElement.value = "Submitting...";
    submitButtonElement.disabled = true;

    xhr = new XMLHttpRequest();
    var nameField = document.getElementById("nameTextId").value;
    var emailField = document.getElementById("emailTextId").value;
    var dateField = document.getElementById("dateTextId").value;
    var lengthField = document.getElementById("lengthTextId").value;
    var locationField = document.getElementById("locationTextId").value;
    var timeField = document.getElementById("timeTextId").value;

    var params = "name=" + nameField + "&email=" + emailField + "&date=" + dateField + "&length=" + lengthField + "&location=" + locationField + "&time=" + timeField;

    xhr.open('POST', 'http://playground.hotaru-development.com/contact.php', true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.setRequestHeader("Content-length", params.length);
    xhr.setRequestHeader("Connection", "close");

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            submitButtonElement.value = "Submitted";
        }
    }

    xhr.send(params);
}